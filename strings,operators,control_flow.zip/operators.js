// airthmatic opretors

// + * - / % **


// single line comment
/* multi line comment*/

// var a = 20; // case sensitive
// var A = 20; // case sensitive


// console.log(20+10);
// console.log(20-10);
// console.log(20*10);
// console.log(20/10);
// console.log(20%10); // modulus
// console.log(2**3); // exponentiation

// assignment operators

// var x = y = 10
// var x, y;

// x = 10
// y = 10

var a = 10; // = asignment operator
// var a = a + 20; 
// a +=  20; 
// a *=  20; 
// a **=  20; 

// console.log(a);

// comparrison operators - True or False
// var a = 10
// var b = '10'

// console.log(a > b);
// console.log(a >= b);

// console.log(a < b);
// console.log(a <= b);

// console.log(a == b);
// console.log(a != b);


// console.log(a === b); // value and type
// console.log(a !== b); // value and type


// logical operators

var a = 10
var b = 20

// console.log(a > 10 && b > 10);
// console.log(a > 10 || b > 10);
// console.log(!(a > 10));
// console.log(typeof check);




// Boolean check

// check = 0 // false
// check = 1 // True
// check = "hello" // True
// check = "" // false
// check = null // false
// check = undefined // false
// check = Array() // True
// check = [] // True
// check = {} // True


// console.log(Boolean(check));

