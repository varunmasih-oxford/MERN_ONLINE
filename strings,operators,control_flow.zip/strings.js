str = 'hello all'
str = "hello all"
str = `hello all`

str = "this is anita's new iphone"
str = 'this is anita\'s new iphone'
str = 'this is anita new "iphone" '
stud_name = 'anita'
str = 'hello ' + stud_name + ' welcome to js'
str = `hello ${stud_name} welcome to js`
str = `hello all`
