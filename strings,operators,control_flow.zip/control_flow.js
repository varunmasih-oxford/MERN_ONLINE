// code exicuted
// code exicuted

// code_status = "no"
// if (code_status === "yes") {
//     console.log("hey");
// }

// code exicuted
// code exicuted


// if(True){Exicute}
// if(false){do not Exicute}

// var age = 10


// if (age >= 18) {
//     console.log("yes you're 18+");
// }

// if (age >= 18) {
//     console.log("yes you're 18+");
// }else {
//     console.log("no you're not 18+");
// }
    

// age below 18 - child
// age 18 to 60 - adult
// age above 60 - senior citizen

// min age > 0--------------
// max age < 120 -----------
// var age = prompt("Enter your age");


// if (age < 18) {
//     console.log("child");
// } else if (age >= 18 && age <= 60) {
//     console.log("adult");
// }else {
//     console.log("senior citizen");
// }



// Vending Machine examle
choose_item = prompt("Choose your item: 1. Coca Cola 2. Pepsi 3. Sprite");
// console.log(typeof choose_item);

choose_item = Number(choose_item); // type conversion




switch (choose_item) {
    case 1:
        console.log("Coca Cola");
        break;
    case 2:
        console.log("Pepsi");
        break;
    case 3:
        console.log("Sprite");
        break;
    default:
        console.log("Invalid item");
        break;
}
    